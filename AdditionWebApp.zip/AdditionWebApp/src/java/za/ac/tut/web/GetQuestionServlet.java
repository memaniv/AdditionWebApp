package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.QuizSBLocal;

/**
 *
 * @author MemaniV
 */
public class GetQuestionServlet extends HttpServlet {
    @EJB QuizSBLocal qsl;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        int num1 = qsl.generateNumber();
        int num2 = qsl.generateNumber();
        String question = qsl.generateQuestion(num1, num2);

        session.setAttribute("num1", num1);
        session.setAttribute("num2", num2);
        session.setAttribute("question", question);
        
        RequestDispatcher disp = request.getRequestDispatcher("ask_question.jsp");
        disp.forward(request, response);
    }

}



