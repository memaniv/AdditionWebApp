package za.ac.tut.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.bl.LoginDetailsSBLocal;

/**
 *
 * @author MemaniV
 */
public class StartSessionServlet extends HttpServlet {
    @EJB LoginDetailsSBLocal ldl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String correctUsername = getServletContext().getInitParameter("correct_username");
        String correctPassword = getServletContext().getInitParameter("correct_password");
        
        boolean outcome = ldl.checkLoginDetails(username, password, correctUsername, correctPassword);
                
        //perform business logic
        if(outcome){
            HttpSession session = request.getSession(true);
            initializeSession(session);
            RequestDispatcher disp = request.getRequestDispatcher("session_started.jsp");
            disp.forward(request, response);
        } else {
            response.sendRedirect("login.html");
        }
    }

    private void initializeSession(HttpSession session) {
        List<String> questions = new ArrayList<>();
        List<String> answers = new ArrayList<>();
        List<String> usersAnswers = new ArrayList<>();
        int numQuestionsAsked = 0, numCorrectAnswers = 0, numWrongAnswers = 0;
        
        session.setAttribute("questions", questions);
        session.setAttribute("answers", answers);
        session.setAttribute("usersAnswers", usersAnswers);
        session.setAttribute("numQuestionsAsked", numQuestionsAsked);
        session.setAttribute("numCorrectAnswers", numCorrectAnswers);
        session.setAttribute("numWrongAnswers", numWrongAnswers);       
    }
}


