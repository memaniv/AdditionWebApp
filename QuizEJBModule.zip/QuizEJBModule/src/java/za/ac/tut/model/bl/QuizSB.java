package za.ac.tut.model.bl;

import javax.ejb.Stateless;

/**
 *
 * @author MemaniV
 */
@Stateless
public class QuizSB implements QuizSBLocal {

    @Override
    public int generateNumber() {
        int num = 1 + (int)Math.floor(Math.random()*10);
        return num;
    }
    
    @Override
    public String generateQuestion(int num1, int num2) {
        String question = num1 + " + " + num2 + " = ?";
        return question;
    }

    @Override
    public String getAnswer(int num1, int num2) {
        int sum = num1 + num2;
        return Integer.toString(sum);
    }

    @Override
    public String determineOutcome(String userAnswer, String correctAnswer) throws AdditionNumbersException {
        String outcome = "Wrong";
        
        if(isAnswerValid(userAnswer)){
            if(userAnswer.equals(correctAnswer)){
                outcome = "Correct";
            }
        } else {
            throw new AdditionNumbersException(userAnswer + " is invalid. Please provide an answer between 2 and 20,inclusive.");
        }

        return outcome;
    }

    private boolean isAnswerValid(String userAnswer) {
        boolean isValid = false;
        
        int answer = Integer.parseInt(userAnswer);
        
        if(answer > 1 && answer < 21){
            isValid = true;
        }
        
        return isValid;
    }
}

