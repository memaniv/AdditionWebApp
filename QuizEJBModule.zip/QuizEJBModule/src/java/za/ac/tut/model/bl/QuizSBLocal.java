/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import javax.ejb.Local;
import javax.servlet.http.HttpSession;

/**
 *
 * @author MemaniV
 */
@Local
public interface QuizSBLocal {
    int generateNumber();
    String generateQuestion(int num1, int num2);
    String getAnswer(int num1, int num2);
    public String determineOutcome(String userAnswer, String correctAnswer) throws AdditionNumbersException;
}
