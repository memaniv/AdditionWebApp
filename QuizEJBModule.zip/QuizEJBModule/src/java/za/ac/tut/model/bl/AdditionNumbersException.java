package za.ac.tut.model.bl;

import javax.ejb.EJBException;

/**
 *
 * @author MemaniV
 */
public class AdditionNumbersException extends EJBException {
    public AdditionNumbersException(String errMsg){
        super(errMsg);
    }
}


