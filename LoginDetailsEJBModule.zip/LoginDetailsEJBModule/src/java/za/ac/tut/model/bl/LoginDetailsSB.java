package za.ac.tut.model.bl;

import javax.ejb.Stateless;

/**
 *
 * @author MemaniV
 */
@Stateless
public class LoginDetailsSB implements LoginDetailsSBLocal {

    @Override
    public boolean checkLoginDetails(String username, String password, String correctUsername, String correctPassword) {
        boolean isValid = false;
        
        if(username.equals(correctUsername) && password.equals(correctPassword)){
            isValid = true;
        }
        
        return isValid;
    }

}


